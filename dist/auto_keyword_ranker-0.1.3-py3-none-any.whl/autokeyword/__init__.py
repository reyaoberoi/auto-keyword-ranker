"""autokeyword package."""
__all__ = ["rank_keywords"]

from .core import rank_keywords
version = "0.1.2"