"""autokeyword package."""
__all__ = ["rank_keywords"]

from .core import rank_keywords
__version__ = "0.1.0"